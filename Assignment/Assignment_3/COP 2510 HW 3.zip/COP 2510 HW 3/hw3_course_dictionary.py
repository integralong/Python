#Lauren Song
#U79789182
#Course Information

course_num = ('COP 2510', 'EGN 3000L', 'MAC 2281', 'MUH 3016', 'PHY 2048')
course_info = {
    'COP 2510' : ['Programming Concepts', 'S.Small', 'TR 8:00am - 9:15am'],
    'EGN 3000L' : ['Foundations of Engineering Lab', 'J.Anderson', 'TR 11:00am - 12:15pm'],
    'MAC 2281' : ['Calculus I', 'A.Makaryus', 'MW 9:30am - 10:45am'],
    'MUH 3016' : ['Survey of Jazz', 'A.Wilkins', 'online asynchronous'],
    'PHY 2048' : ['General Physics I', 'G.Pradhan', 'TR 5:00pm - 6:15pm']
}

course_num = input('Enter a course number:')

if course_num == 'COP 2510':
    print('The course details are:')
    print("Course Name:", course_info['COP 2510'][0])
    print("Instructor:", course_info['COP 2510'][1])
    print("Class Times:", course_info['COP 2510'][2])
elif course_num == 'EGN 3000L':
    print('The course details are:')
    print("Course Name:", course_info['EGN 3000L'][0])
    print("Instructor:", course_info['EGN 3000L'][1])
    print("Class Times:", course_info['EGN 3000L'][2])
elif course_num == 'MAC 2281':
    print('The course details are:')
    print("Course Name:", course_info['MAC 2281'][0])
    print("Instructor:", course_info['MAC 2281'][1])
    print("Class Times:", course_info['MAC 2281'][2])   
elif course_num == 'MUH 3016':
    print('The course details are:')
    print("Course Name:", course_info['MUH 3016'][0])
    print("Instructor:", course_info['MUH 3016'][1])
    print("Class Times:", course_info['MUH 3016'][2])
elif course_num == 'PHY 2048':
    print('The course details are:')
    print("Course Name:", course_info['PHY 2048'][0])
    print("Instructor:", course_info['PHY 2048'][1])
    print("Class Times:", course_info['PHY 2048'][2])
else:
    print(f'{course_num} is an invalid course number.') 



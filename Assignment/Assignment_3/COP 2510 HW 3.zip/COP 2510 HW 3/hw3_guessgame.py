#Lauren Song
#U79789182
#Guessing Game

import random
r = random.randint(1,100)

tries = 0

while tries < 10:
    number = int(input('Enter a number between 1 and 100(inclusive):'))
    
    if number < 1 or number > 100:
        continue


    while number in range(0,101) and tries < 9:
        tries += 1

        if 100 >= number > r:
            number = int(input('Too high. Enter another guess:'))
        elif 1 <= number < r:
            number = int(input('Too low. Enter another guess:'))
        elif number == r:
            print(f'You guessed it right!! You got it in {tries} guesses!')
            break
        
    if tries == 9:
        print(f'Sorry, the number was {r}')
        break
            
    if number == r:
        break



